package com.example.beybladenumberguess;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.provider.ContactsContract;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.text.NumberFormat;

public class guesser extends AppCompatActivity {
    private Button button;
    public static final String ress = "howtheydotho";
    public static final String thename = "howdotho";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guesser);
        TextView beView= (TextView) findViewById(R.id.between);
        Intent i = getIntent();
        int temp = i.getIntExtra(diff.pass,100);
        int which = i.getIntExtra(diff.pass2,100);
        Log.d("App", String.valueOf(which));

        ImageView avView = (ImageView) findViewById(R.id.avatar);
        if(which == 2){
            avView.setImageResource(R.drawable.p2);
        }
        else if(which==3){
            avView.setImageResource(R.drawable.p3);

        }
        beView.setText("Between 1 and "+temp);

        timer(true);


    }
    public void cnt(){
        if(round==10){
            button = findViewById(R.id.cont);
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    openMainActivity2();
                }
            });
        }
    }

    public void openMainActivity2(){
        Intent i = getIntent();
        //String name2 = i.getStringExtra(winlose.nim);

        String nam = i.getStringExtra(diff.pass3);

        Intent intent = new Intent(this,winlose.class);
        intent.putExtra(ress, score);
      //  if(name2.equals(" ")){
            intent.putExtra(thename, nam);

      //  }
       /// else{
          //  intent.putExtra(thename, name2);

        //}


        startActivity(intent);
    }
    //private double rand;
    private int round = 1;
    private boolean newRound = false;
    private int result =0;
    CountDownTimer timer;
    private int score =0;
    private int barSize =0;
    DisplayMetrics displayMetrics = new DisplayMetrics();

    public void timer(boolean onoroff){
        timer = new CountDownTimer(20000, 1000){
            TextView timerView = (TextView) findViewById(R.id.timer);
            Button barView=(Button) findViewById(R.id.timerbar);
            ViewGroup.LayoutParams layoutParams = barView.getLayoutParams();


            public void onTick(long millisUntilFinished) {
                NumberFormat f = new DecimalFormat("00");
                long sec = (millisUntilFinished / 1000) % 60;
                timerView.setText(f.format(sec));
                getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
                int width = displayMetrics.widthPixels;
                barSize+=(width/20);
                layoutParams.width=barSize;
                if(barSize <= width/3){
                    barView.setBackgroundColor(Color.GREEN);
                }
                else if(barSize >width/3 && barSize<= 2*(width/3)){
                    barView.setBackgroundColor(Color.YELLOW);
                }
                else{
                    barView.setBackgroundColor(Color.RED);

                }
                barView.setLayoutParams(layoutParams);
            }

            public void onFinish() {
                timerView.setText("00");
                TextView messageView= (TextView) findViewById(R.id.message);
                messageView.setVisibility(View.INVISIBLE);
                TextView beView= (TextView) findViewById(R.id.between);
                beView.setVisibility(View.INVISIBLE);
                EditText guessView=(EditText) findViewById(R.id.guess);
                guessView.setVisibility(View.INVISIBLE);

                Button lirView=(Button) findViewById(R.id.lir);
                lirView.setVisibility(View.INVISIBLE);
                TextView rorwView= (TextView) findViewById(R.id.rorw);
                rorwView.setVisibility(View.VISIBLE);
                Button contView=(Button) findViewById(R.id.cont);
                contView.setVisibility(View.VISIBLE);
                TextView sureView= (TextView) findViewById(R.id.sure);
                sureView.setVisibility(View.INVISIBLE);
                Button yesView=(Button) findViewById(R.id.yes);
                yesView.setVisibility(View.INVISIBLE);
                Button noView=(Button) findViewById(R.id.no);
                noView.setVisibility(View.INVISIBLE);
                rorwView.setText("WRONG BUM");

                round = 10;

            }
        };
        if(onoroff) {
            timer.start();
        }
        else if (!onoroff){
            timer.cancel();
        }
    }

    public void letitrip(View v){
        EditText guessView=(EditText) findViewById(R.id.guess);
        String gV = guessView.getText().toString();
        Button lirView = (Button) findViewById(R.id.lir);
        Intent i = getIntent();
        int temp = i.getIntExtra(diff.pass,100);

        if (!(gV.equals(""))) {
            int guess = Integer.valueOf(gV);
            if(guess >=0 && guess <= temp){
                TextView rorwView = (TextView) findViewById(R.id.rorw);
                rorwView.setVisibility(View.INVISIBLE);
                Button contView = (Button) findViewById(R.id.cont);
                contView.setVisibility(View.INVISIBLE);
                TextView messageView = (TextView) findViewById(R.id.message);
                messageView.setVisibility(View.INVISIBLE);
                TextView betView = (TextView) findViewById(R.id.between);
                betView.setVisibility(View.INVISIBLE);
                guessView.setVisibility(View.INVISIBLE);

                lirView.setVisibility(View.INVISIBLE);
                TextView sureView = (TextView) findViewById(R.id.sure);
                sureView.setVisibility(View.VISIBLE);
                Button yesView = (Button) findViewById(R.id.yes);
                yesView.setVisibility(View.VISIBLE);
                Button noView = (Button) findViewById(R.id.no);
                noView.setVisibility(View.VISIBLE);
                ImageView avView = (ImageView) findViewById(R.id.avatar);
                avView.setVisibility(View.VISIBLE);
            }
            else{
                lirView.setError("guess cannot a number that's not 0-"+temp);

                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    public void run() {

                        lirView.setError(null);
                    }
                }, 3000);
            }



        }
        else {
            lirView.setError("guess cannot be null");

            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                public void run() {

                    lirView.setError(null);
                }
            }, 3000);

        }
    }
    public void no(View v){
        if(round<=9) {
            if (newRound) {
                timer.start();
                round++;
                barSize = 0;
                newRound = false;
            }
            TextView rorwView = (TextView) findViewById(R.id.rorw);
            rorwView.setVisibility(View.INVISIBLE);
            Button contView = (Button) findViewById(R.id.cont);
            contView.setVisibility(View.INVISIBLE);
            TextView messageView = (TextView) findViewById(R.id.message);
            messageView.setVisibility(View.VISIBLE);
            TextView betView = (TextView) findViewById(R.id.between);
            betView.setVisibility(View.VISIBLE);
            EditText guessView = (EditText) findViewById(R.id.guess);
            guessView.setVisibility(View.VISIBLE);

            Button lirView = (Button) findViewById(R.id.lir);
            lirView.setVisibility(View.VISIBLE);
            TextView sureView = (TextView) findViewById(R.id.sure);
            sureView.setVisibility(View.INVISIBLE);
            Button yesView = (Button) findViewById(R.id.yes);
            yesView.setVisibility(View.INVISIBLE);
            Button noView = (Button) findViewById(R.id.no);
            noView.setVisibility(View.INVISIBLE);
            ImageView avView = (ImageView) findViewById(R.id.avatar);
            avView.setVisibility(View.INVISIBLE);
        }
        else{
            TextView rorwView= (TextView) findViewById(R.id.rorw);
            rorwView.setVisibility(View.INVISIBLE);
            Button contView=(Button) findViewById(R.id.cont);
            contView.setVisibility(View.VISIBLE);
            TextView sureView= (TextView) findViewById(R.id.sure);
            sureView.setVisibility(View.INVISIBLE);
            Button yesView=(Button) findViewById(R.id.yes);
            yesView.setVisibility(View.INVISIBLE);
            Button noView=(Button) findViewById(R.id.no);
            noView.setVisibility(View.INVISIBLE);
            ImageView avView = (ImageView) findViewById(R.id.avatar);
            avView.setVisibility(View.INVISIBLE);
            cnt();
        }

    }
    public void yes(View v){
        Button barView=(Button) findViewById(R.id.timerbar);
        ViewGroup.LayoutParams layoutParams = barView.getLayoutParams();
        int speed = layoutParams.width;
        layoutParams.width=0;
        barView.setLayoutParams(layoutParams);
        timer.cancel();
        TextView timerView = (TextView) findViewById(R.id.timer);

        timerView.setText("00");

        TextView rorwView= (TextView) findViewById(R.id.rorw);
        rorwView.setVisibility(View.VISIBLE);
        Button contView=(Button) findViewById(R.id.cont);
        contView.setVisibility(View.VISIBLE);
        TextView sureView= (TextView) findViewById(R.id.sure);
        sureView.setVisibility(View.INVISIBLE);
        Button yesView=(Button) findViewById(R.id.yes);
        yesView.setVisibility(View.INVISIBLE);
        Button noView=(Button) findViewById(R.id.no);
        noView.setVisibility(View.INVISIBLE);

        EditText guessView=(EditText) findViewById(R.id.guess);
        double gV = Double.parseDouble(guessView.getText().toString());
        TextView scoreView= (TextView) findViewById(R.id.score);
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);

        int hard = 0;
        int width = displayMetrics.widthPixels;
        /*
        if(temp.equals("e")) hard =5;
        else if(temp.equals("h")) hard =10;


         */
        Intent i = getIntent();
        int temp = i.getIntExtra(diff.pass,100);
        if (gV == random(temp)){
            rorwView.setText("YESSIR");
            newRound=true;
            result++;
            score = score + 100;
            if(speed<=width/5){
                score+=50;
            }
            else if(speed>width/5 && speed<=2*(width/5)){
                score+=30;
            }
            else if(speed>2*(width/5) && speed<=3*(width/5)){
                score+=15;
            }
            else if(speed>3*(width/5) && speed<=4*(width/5)){
                score+=7;
            }
            else{
                score+=2;
            }
            scoreView.setText("SCORE: "+score);
        }
        else{
            rorwView.setText("WRONG BUM");
            scoreView.setVisibility(View.INVISIBLE);
            round =10;

        }
    }

    public double random(int n){
        double rand = Math.floor((Math.random()*n) +1);
        return rand;
    }


}
