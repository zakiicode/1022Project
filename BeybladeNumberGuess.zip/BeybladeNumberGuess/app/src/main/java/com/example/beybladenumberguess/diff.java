package com.example.beybladenumberguess;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class diff extends AppCompatActivity {

    private Button button;
    private Button button2;
    public static final String pass = "passed";
    public static final String pass2 = "passed2";

    private int diff =0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diff);
        button = findViewById(R.id.button5);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                diff=5;
                openMainActivity2();
            }
        });
        button2 = findViewById(R.id.button6);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                diff=10;
                openMainActivity2();
            }
        });
    }
    public void openMainActivity2(){
        Intent i = getIntent();
        int choice = i.getIntExtra(sure.chara,0);
        Intent intent = new Intent(this,guesser.class);
        intent.putExtra(pass, diff);
        intent.putExtra(pass2, choice);

        startActivity(intent);
    }


}