package com.example.beybladenumberguess;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class mainmenu extends AppCompatActivity {
    private Button button;
    private Button button2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        MediaPlayer music = MediaPlayer.create(mainmenu.this,R.raw.beysong);
        music.start();
        music.setLooping(true);
        button=findViewById(R.id.button2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openRules();

            }
        });
        button2=findViewById(R.id.next);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                start();

            }
        });



    }
    public void start(){
        Intent intent=new Intent(this,name.class);
        startActivity(intent);
    }
    public void openRules(){
        Intent intent=new Intent(this,rules.class);
        startActivity(intent);
    }
}