package com.example.beybladenumberguess;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class name extends AppCompatActivity {
    private Button button;
    public static final String nem = "thename";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_name);
        button=findViewById(R.id.next);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open();

            }
        });
    }

    public void open(){
        Intent intent = new Intent(this,avatar.class);
        EditText e = findViewById(R.id.name);
        String nom = e.getText().toString();
        Button but =findViewById(R.id.next);

        if (!(nom.equals(""))) {

            intent.putExtra(nem, nom);
            startActivity(intent);
        }
        else{
            but.setError("enter a proper name bro");

            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                public void run() {

                    but.setError(null);
                }
            }, 3000);
        }
    }
}