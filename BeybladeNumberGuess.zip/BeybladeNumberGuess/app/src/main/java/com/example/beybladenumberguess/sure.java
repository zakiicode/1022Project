package com.example.beybladenumberguess;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class sure extends AppCompatActivity {
    private Button button;
    public static final String chara = "avat";
    public static final String n = "thename";

    private int where =0;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sure);
        button = findViewById(R.id.yes);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                opennext();
            }
        });
    }
    public void opennext(){
        Intent i = getIntent();
        int choice = i.getIntExtra(avatar.avat,9);
        String nam = i.getStringExtra(avatar.nombre);
        Intent intent = new Intent(this, diff.class);
        intent.putExtra(chara, choice);
        intent.putExtra(n,nam);

        startActivity(intent);


    }

}