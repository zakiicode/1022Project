package com.example.beybladenumberguess;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.transition.ScaleProvider;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class highscore extends AppCompatActivity {

    private Context mcontext;
    private Button button;
    public ArrayList<Integer> w = new ArrayList<>(10);
    public ArrayList<String> w1 = new ArrayList<String>();
    public ArrayList<String> names = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_highscore);
        Intent i = getIntent();
        int x = i.getIntExtra(winlose.score, 0);
        String nam = i.getStringExtra(winlose.nim);

        gethighscores(x,nam);
        button = (Button) findViewById(R.id.next);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goback();
            }
        });
    }


    public void goback() {
        Intent intent = new Intent(getApplicationContext(), winlose.class);
        startActivity(intent);
    }


    public void gethighscores(int r, String f) {



        TextView Score1 = findViewById(R.id.Score1);
        TextView Score2 = findViewById(R.id.Score2);
        TextView Score3 = findViewById(R.id.Score3);
        TextView Score4 = findViewById(R.id.Score4);
        TextView Score5 = findViewById(R.id.Score5);
        TextView name1 = findViewById(R.id.name1);
        TextView name2 = findViewById(R.id.name2);
        TextView name3 = findViewById(R.id.name3);
        TextView name4 = findViewById(R.id.name4);
        TextView name5 = findViewById(R.id.name5);
        String [] nams = {"mike","steve","jim","bob","alejandro","raj","goku","gingka","tyler"};
        int counter = 0;
        for (int i = 0; i < 5; i++) {
            int rand =  (int) Math.floor((Math.random()*1500) +1);
            int rannd = (int) Math.floor((Math.random()*8) +1);

            String rand2 = String.valueOf(rand);
            w.add(rand);
            names.add(nams[rannd]);
        }
        int i = 0;
        Collections.sort(w);

        Collections.reverse(w);
        for (int x = 0; x < 5; x++) {

            Log.d("App", String.valueOf(w.get(x)));
        }
        for (i = 0; i < 5; i++) {
            String p = String.valueOf(w.get(i));
            int u = Integer.parseInt(p);

            if (u > r) {
                counter++;
                w1.add(p);
            } else {
                String z = String.valueOf(r);
                w1.add(z);
                names.set(i, f);
                break;
            }
        }
        for (i = i; i < 5; i++) {
            try {
                String p = String.valueOf(w.get(i));
                w1.add(p);
            } catch (Exception e) {
            }
        }
        if (counter != 5) {
            w.remove(4);
        }
        Score1.setText(w1.get(0));
        Score2.setText(w1.get(1));
        Score3.setText(w1.get(2));
        Score4.setText(w1.get(3));
        Score5.setText(w1.get(4));
        name1.setText(names.get(0));
        name2.setText(names.get(1));
        name3.setText(names.get(2));
        name4.setText(names.get(3));
        name5.setText(names.get(4));
    }
}
