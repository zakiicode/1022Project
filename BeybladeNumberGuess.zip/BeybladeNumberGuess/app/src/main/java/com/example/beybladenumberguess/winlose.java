package com.example.beybladenumberguess;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class winlose extends AppCompatActivity {
    private Button button;
    private Button button2;
    private Button button3;
    public static final String score = "scoo";
    public static final String nim = "scoeeo";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_winlose);
        Intent i = getIntent();
        int temp = i.getIntExtra(guesser.ress,100);


        TextView mess= (TextView) findViewById(R.id.MESSAGE);

        if(temp>=0 && temp <=200){
            mess.setText("Damn bro you did bad ong");
        }
        else if(temp>=201 && temp <=600){
            mess.setText("not bad, better than most");

        }
        else if(temp>=601){
            mess.setText("YOU ARE AN ELITE BLADER");

        }
        button = (Button) findViewById(R.id.next);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OpenHighscores();
            }
        });
        button2 = (Button) findViewById(R.id.restart);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                restart();
            }
        });
        button3 = (Button) findViewById(R.id.menu);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                menu();
            }
        });
    }
    public void OpenHighscores(){
        Intent intent = new Intent(this, highscore.class);
        Intent i = getIntent();

        int temp = i.getIntExtra(guesser.ress,100);
        String nam = i.getStringExtra(guesser.thename);
        intent.putExtra(score, temp);
        intent.putExtra(nim, nam);

        startActivity(intent);
    }
    public void restart(){
        Intent intent = new Intent(this, guesser.class);
       // String nam = intent.getStringExtra(guesser.thename);
        //intent.putExtra(nim, nam);

        startActivity(intent);
    }
    public void menu(){
        Intent intent = new Intent(this, mainmenu.class);
        startActivity(intent);
    }
}