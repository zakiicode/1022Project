package com.example.beybladenumberguess;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class winlose extends AppCompatActivity {
    private Button button;
    private Button button2;
    private Button button3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_winlose);
        Intent i = getIntent();
        int temp = i.getIntExtra(guesser.ress,100);
        TextView mess= (TextView) findViewById(R.id.MESSAGE);

        if(temp>=0 && temp <=2){
            mess.setText("Damn bro you did bad ong");
        }
        else if(temp>=3 && temp <=6){
            mess.setText("not bad, better than most");

        }
        else if(temp>=7 && temp <=10){
            mess.setText("YOU ARE AN ELITE BLADER");

        }
        button = (Button) findViewById(R.id.next);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OpenHighscores();
            }
        });
        button2 = (Button) findViewById(R.id.restart);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                restart();
            }
        });
        button3 = (Button) findViewById(R.id.menu);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                menu();
            }
        });
    }
    public void OpenHighscores(){
        Intent intent = new Intent(this, highscore.class);
        startActivity(intent);
    }
    public void restart(){
        Intent intent = new Intent(this, guesser.class);
        startActivity(intent);
    }
    public void menu(){
        Intent intent = new Intent(this, mainmenu.class);
        startActivity(intent);
    }
}